package com.example.musicplayer.ui.play

interface SeekListener {
    fun seekTo(seek: Long)
}