package com.example.musicplayer.ui.main

interface ClickListener<T> {
    fun click(model: T)
}